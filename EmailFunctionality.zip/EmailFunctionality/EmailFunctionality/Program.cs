﻿using System;
using System;

namespace EmailFunctionality
{
    class Program
    {
        static void Main(string[] args)
        {
            //call methods or create extensions..
        }
    }
}
