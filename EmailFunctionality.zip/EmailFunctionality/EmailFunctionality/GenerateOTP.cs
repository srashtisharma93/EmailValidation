﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace EmailFunctionality
{
    class GenerateOTP
    {
        /// <summary>
        /// Generate OTP for email
        /// </summary>
        /// <param name="user_email">user email address</param>
        /// <returns>OTP generated</returns>
        public static string generate_OTP_email(string user_email)
        {
            string result = string.Empty;
            try
            {
                bool isEmail = System.Text.RegularExpressions.Regex.IsMatch(user_email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}
                                                ~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
                if (user_email.EndsWith("@dso.org.sg") && isEmail)
                {
                    Random random = new Random();
                    int OTPCode = random.Next(100000, 999999);
                    result = $"You OTP Code is {OTPCode}.The code is valid for 1 minute, STATUS_EMAIL_OK: email containing OTP has been sent successfully";
                    //Store the OTP in database with user_email address
                }
                else
                {
                    result = "Invalid email address,STATUS_EMAIL_INVALID: email address is invalid.";
                }
            }
            catch (Exception ex)
            {
                result = "STATUS_EMAIL_FAIL: email address does not exist or sending to the email has failed.";
            }
            return result;
        }

    }
}
